// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

var HEIGHT_Y = 1.5;
var XYZ = [[-8.061,HEIGHT_Y,2.491], [-8.699,HEIGHT_Y,4.469], [-9.267,HEIGHT_Y,6.324], [-9.846,HEIGHT_Y,8.178], [-10.462,HEIGHT_Y,10.106], [-11.075,HEIGHT_Y,12.089], [-11.642,HEIGHT_Y,13.947]];
var THINGS = {'MEL.AR.W2000':'1', 'MEL.AR.W2100':'2', 'MEL.AR.W2200':'3', 'MEL.AR.W2300':'4', 'MEL.AR.W2400':'5', 'MEL.AR.W2500':'6', 'MEL.AR.W2600':'7'};
var interval_update;
var ThingTemplate = 'MEL.AR.RTT';
var data = {};
    data.dataShape = {};
    data.dataShape.fieldDefinitions = {"name":{"name":"name","baseType":"STRING"},"description":{"name":"description","baseType":"STRING"}};
    data.rows = [];
    data.rows[0] = {"name":"Visible","description":""};
    data.rows[1] = {"name":"UnitName","description":""};
    data.rows[2] = {"name":"ErrorCodeTitle","description":""};
    data.rows[3] = {"name":"ErrorDetail","description":""};
    data.rows[4] = {"name":"StatusColor","description":""};
    data.rows[5] = {"name":"ProdPercentTitle","description":""};

//装置名、エラー内容、残量など表示
$scope.renderSVGxhtml = function(imgWidget, devTitle, errTitle, errMsg, percent) {
  let svgData = `<?xml version="1.0" encoding="UTF-8"?>
  <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
  <svg 
    id="svg1" 
    crossorigin="anonymous"
    xmlns="http://www.w3.org/2000/svg" 
    xmlns:xlink="http://www.w3.org/1999/xlink" 
    xmlns:xhtml="http://www.w3.org/1999/xhtml"
    width="260" height="130" >
    <foreignObject x="0" y="0" width="260" height="40">
        <xhtml:div 
          id='svgcontainer' 
          style="display:flex;justify-content:center;align-content:center;flex-direction:column;font-family:Meiryo;font-size:24px;text-align:center;background-color:transparent;color:white;">
            <xhtml:b>${devTitle}<xhtml:hr/></xhtml:b>
        </xhtml:div>
    </foreignObject>
    <foreignObject x="5" y="30" width="260" height="30">
        <xhtml:div 
          id='svgcontainer' 
          style="display:flex;justify-content:center;align-content:center;flex-direction:column;font-family:Meiryo;font-size:14px;text-align:center;background-color:transparent;color:white;">
            <xhtml:p>${errTitle}</xhtml:p>
        </xhtml:div>
    </foreignObject>
    <foreignObject x="5" y="50" width="260" height="30">
        <xhtml:div 
          id='svgcontainer' 
          style="display:flex;justify-content:center;align-content:center;flex-direction:column;font-family:Meiryo;font-size:14px;text-align:center;background-color:transparent;color:white;">
            <xhtml:p>${errMsg}</xhtml:p>
        </xhtml:div>
    </foreignObject>
    <foreignObject x="114" y="104" width="100" height="30">
        <xhtml:div 
          id='svgcontainer' 
          style="display:flex;justify-content:center;align-content:center;flex-direction:column;font-family:Meiryo;font-size:18px;text-align:center;background-color:transparent;color:white;">
            <xhtml:b>${percent}<xhtml:hr/></xhtml:b>
        </xhtml:div>
    </foreignObject>
  </svg>`;
  
  //console.warn("svgData"); console.info(svgData);
  // Base64 encode the SVG template defined above and create the SVG URL
  let svgURL = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgData)));
  //console.info(imgWidget +" svgURL：" + svgURL);
  // Set the image widget to the SVG URL
  $scope.setWidgetProp(imgWidget,'src',svgURL);
}

//データ読込
function updateAll() {
  twx.app.fn.triggerDataService(ThingTemplate, 'QueryImplementingThingsWithNamedData', {'propertyNames':data});
}

//データ更新
$scope.$on(('QueryImplementingThingsWithNamedData.serviceInvokeComplete'), function(evt, arg) {
  //console.log('MEL.AR.RTT: ' + JSON.stringify($scope.app.mdl[ThingTemplate].svc['QueryImplementingThingsWithNamedData'].data));
  for (var i=0; i<XYZ.length; i++) {
    var thingData = $scope.app.mdl[ThingTemplate].svc['QueryImplementingThingsWithNamedData'].data[i];
    var thingName = thingData.name;
    var idx = THINGS[thingName];

    if (idx) {
      $scope.view.wdg["3DGauge-"+idx]["visible"] = thingData.Visible;
      $scope.view.wdg["3DImage-"+idx]["visible"] = thingData.Visible;
      $scope.view.wdg["3DImage-"+idx+"1"]["visible"] = thingData.Visible;
      $scope.view.wdg["3DImage-"+idx+"2"]["visible"] = thingData.Visible;
      
      //$scope.view.wdg["3DImage-"+idx]["src"] = thingData.StatusColor;
      $scope.setWidgetProp("3DImage-"+idx,'src', thingData.StatusColor);
      $scope.renderSVGxhtml("3DImage-"+idx+"2", thingData.UnitName, thingData.ErrorCodeTitle, thingData.ErrorDetail, thingData.ProdPercentTitle);
    }
  }
});

//リセット後、データ更新
$scope.$on(('ResetData.serviceInvokeComplete'), function(evt, arg) {
  console.log('MEL.AR.RTT: ResetData');
  updateAll();
});

//座標設定
$timeout(function () {
  for (var i=1; i<(XYZ.length+1); i++) {
    var loc = XYZ[i-1];
    //背景
    $scope.view.wdg["3DGauge-"+i]["x"] = loc[0];
    $scope.view.wdg["3DGauge-"+i]["y"] = loc[1];
    $scope.view.wdg["3DGauge-"+i]["z"] = loc[2];
    //状態
    $scope.view.wdg["3DImage-"+i]["x"] = loc[0];
    $scope.view.wdg["3DImage-"+i]["y"] = HEIGHT_Y;
    $scope.view.wdg["3DImage-"+i]["z"] =loc[2];
    //リセット
    $scope.view.wdg["3DImage-"+i+"1"]["x"] = loc[0];
    $scope.view.wdg["3DImage-"+i+"1"]["y"] = HEIGHT_Y;
    $scope.view.wdg["3DImage-"+i+"1"]["z"] = loc[2];
    //文字列
    $scope.view.wdg["3DImage-"+i+"2"]["x"] = loc[0];
    $scope.view.wdg["3DImage-"+i+"2"]["y"] = HEIGHT_Y;
    $scope.view.wdg["3DImage-"+i+"2"]["z"] = loc[2];
  }
  // 自動更新
  interval_update = setInterval(updateAll, 10000);
}, 3000);

