﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // メモ: [リファクター] メニューの [名前の変更] コマンドを使用すると、コード、svc、および config ファイルで同時にクラス名 "Service1" を変更できます。
    // 注意: このサービスをテストするために WCF テスト クライアントを起動するには、ソリューション エクスプローラーでService1.svcまたはService1.svc.csを選択し、デバッグを開始してください。
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
                composite.StringValue += composite.comments[0];
            }
            return composite;
        }
        public string NewProc(DummyData dummy)
        {
            //if (dummy.str !== null) return "strはじめまして" + dummy.str + "様";
            //else if (dummy.strs != null) 
                return "はじめまして" + dummy.strs[1] + "様";
        }
    }
}