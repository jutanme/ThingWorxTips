// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

//アプリケーションパラメータ playStep
// ↑ モデルの currentStep が play で自動的に +1 されるため保持用のパラメータ
//
// ステップ移動は各ステップの「再生前」の状態


//”すべて再生（中止されたらそのステップから）”

$scope.playAllStep = function() { 
 
 $scope.setWidgetProp('playButton','visible','false')
 $scope.setWidgetProp('pause','visible','true')

  $scope.setWidgetProp('wayfinder-1','showRibbon', 'true'); 
  $scope.setWidgetProp('wayfinder-1','showWaypoints', 'true');  
  $scope.setWidgetProp('wayfinder-1','showLabels', 'true');   
 setTimeout(function() {
    twx.app.fn.triggerWidgetService( 'model-1', 'playAll');
 },1000);
  
}

//”次のステップで中止”
$scope.pauseStep = function() { 
  
 $scope.setWidgetProp('playButton','visible','true')
 $scope.setWidgetProp('pause','visible','false')
  
 setTimeout(function() {
    twx.app.fn.triggerWidgetService( 'model-1', 'stop');
 },1000); 
}


//”そのステップのみ再生”
$scope.playStep = function() { 
 
 setTimeout(function() {
    twx.app.fn.triggerWidgetService( 'model-1', 'play');
 },1000);
  
}

//ステップ指定
$scope.setPlayStep = function(setstep) {
 $scope.app.params.playStep = setstep; 
 $scope.setCurrentstep();
}


//ボタンクリックで変更されたステップを再生ステップに反映
$scope.setCurrentstep = function() {
  
 $scope.setWidgetProp('model-1','currentStep', $scope.app.params.playStep )
// $scope.setLabelButton() ;
}

/*
//ボタン表示の制御
$scope.setLabelButton = function() {

  var step =  $scope.app.params.playStep ;
    
 if ( step != $scope.view.wdg['model-1']['steps']  ) {
     $scope.setWidgetProp('playButton','visible','true')
 }
  
 if ( step == 1 ) {
     $scope.setWidgetProp('pause','visible','false')
 }
  
}
*/


//各ボタンで playStep の変更


//初期状態に戻る
$scope.resetStep = function() {
  
 $scope.app.params.playStep = 1 ;
 $scope.setCurrentstep();
 $scope.setWidgetProp('playButton','visible','true')
 $scope.setWidgetProp('pause','visible','false')

}

//最終状態まで送り（全ステップ数はモデル情報から取り込み）
$scope.endStep = function() {
  
 $scope.app.params.playStep = $scope.view.wdg['model-1']['steps'] ;
 $scope.setCurrentstep();

}

$scope.$watch("view.wdg['model-1'].currentStep", function(crntStep){ 
  $scope.setWidgetProp('wayfinder-1','selectedWaypointIndex', crntStep-1);
});