// $scope, $element, $attrs, $injector, $timeout, $http, $ionicPopup, and $ionicPopover services are available

//the current example

//=========svg test wrap
// This function accepts an image widget name (imgWidget, ex: '3DImage-1') 
//   and some text/HTML (imgText) to render as an SVG image on the widget. 
//   There are optional arguments for basic features like background color, 
//   font color, font size, etc.
$scope.renderSVGxhtml = function(imgWidget, imgText,  bgColor , fontColor, fontSize='xx-large') {
  // Simple 600x400 SVG image template with a foreignobject section to embed HTML (text). 
  let svgData = `<?xml version="1.0" encoding="UTF-8"?>
  <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
  <svg 
    id="svg1" 
    crossorigin="anonymous"
    xmlns="http://www.w3.org/2000/svg" 
    xmlns:xlink="http://www.w3.org/1999/xlink" 
    xmlns:xhtml="http://www.w3.org/1999/xhtml"
    width="600" height="500" >
    <foreignObject x="0" y="0" width="600" height="250">
        <xhtml:div 
          id='svgcontainer' 
          style="margin:5px;padding:5px;height:480px;display:flex;justify-content:center;align-content:center;flex-direction:column;font-family:Tahoma,sans-serif;font-size:${fontSize};text-align:center;background-color:${bgColor};color:${fontColor};">
            ${imgText}
        </xhtml:div>
    </foreignObject>
    
    <foreignObject x="0" y="250" width="600" height="250">
        <xhtml:div 
          id='svgcontainer' 
          style="margin:5px;padding:5px;height:480px;display:flex;justify-content:center;align-content:center;flex-direction:column;font-family:Tahoma,sans-serif;font-size:${fontSize};text-align:center;background-color:${bgColor};color:${fontColor};">
            ${imgText}
        </xhtml:div>
    </foreignObject>
  </svg>`;
  
  //console.warn("svgData"); console.info(svgData);
  // Base64 encode the SVG template defined above and create the SVG URL
  let svgURL = "data:image/svg+xml;base64," + btoa(svgData);
  // console.warn("svgURL");
  //console.info(svgURL);
  // Set the image widget to the SVG URL
  //$scope.view.wdg[imgWidget].src=svgURL;
  $scope.setWidgetProp(imgWidget,'src',svgURL)
}

//=========================================================================
 $scope.readTextFile =function(filename, functionCall) {
 
   fetch('app/resources/Uploaded/' + filename).then((response) => response.text())
    .then((text) => {
      
      console.warn("txt:::"+ text)
      let evalTxt=functionCall.replace("my_sample_text_here",text)
      console.warn("---> "+evalTxt)
      eval(evalTxt)  
    });
    

}
//=========================================================================
//=========================================================================
// Verify the renderSVG function works by setting a 3DImage widget to text. 
$scope.sampleSVG3 = function() {
  // Name of image widget to edit
  let sampleImgWidget = '3DImage-3';
  // Text to render on 3DImage widget
//  let sampleText = '<xhtml:small>Here is some (samll)<xhtml:hr/></xhtml:small><xhtml:b>(bold)USING The XHTML Syntax <xhtml:hr/></xhtml:b> <xhtml:br/>in  an SVG as <xhtml:b>fofeignObject svgcontainer</xhtml:b><xhtml:br/> <xhtml:i> (italic)which is  working OK! </xhtml:i>';
 //the same line but received by file
 
  // Render sample
  //$scope.renderSVG(imgWidget=sampleImgWidget, imgText=sampleText);
  let bgColor=   '#DE3163'  //'#414141' according https://htmlcolorcodes.com/
  let frontColor= '#40E0D0' //'#FCFCFC'
  
  let myFunctionCall ='$scope.renderSVGxhtml("'+sampleImgWidget+'", "my_sample_text_here","'+bgColor+'", "'+frontColor+'","xx-large");'
 
 $scope.readTextFile('testText1.txt', myFunctionCall)
  
}
//===========================================================================
// Verify the renderSVG function works by setting a 3DImage widget to text. 
//===========================================================================
$scope.sampleSVG4 = function() {
 // Name of image widget to edit
  let sampleImgWidget = '3DImage-4';
  // Text to render on 3DImage widget
//  let sampleText = '<xhtml:small>Here is some (samll)<xhtml:hr/></xhtml:small><xhtml:b>(bold)USING The XHTML Syntax <xhtml:hr/></xhtml:b> <xhtml:br/>in  an SVG as <xhtml:b>fofeignObject svgcontainer</xhtml:b><xhtml:br/> <xhtml:i> (italic)which is  working OK! </xhtml:i>';
 //the same line but received by file
 
  // Render sample
  //$scope.renderSVG(imgWidget=sampleImgWidget, imgText=sampleText);
  let bgColor=   '#FF7F50'  //'#414141' according https://htmlcolorcodes.com/
  let frontColor= '#DFFF00' //'#FCFCFC'
  
  let myFunctionCall ='$scope.renderSVGxhtml("'+sampleImgWidget+'", "my_sample_text_here","'+bgColor+'", "'+frontColor+'","xx-large");'
 
 $scope.readTextFile('testText2.txt', myFunctionCall)
}
//======================================================================================================
//======================================================================================================
// After the document has loaded, change the image to the sample SVG
// angular.element(document).ready($timeout(()=>{$scope.sampleSVG3();$scope.sampleSVG4();},0));

$scope.$on('$ionicView.afterEnter',function(){$timeout(()=>{$scope.sampleSVG3();$scope.sampleSVG4();},0)})
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//-old example stuff for widget with svg not 100% working but good example how to use this functionality
$scope.svg_ret1 = function(imgWidget, height,color1,color2,color3,width1,width2,width3) {
  var txtL=""
   
   var width=(width1+width2+width3);
      var xmlsrc=    '<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n';
/*      xmlsrc= xmlsrc+'<svg xmlns="http://www.w3.org/2000/svg" height="'+height+'" width="'+ width+'">\n'
      xmlsrc= xmlsrc+'<rect x="0" y="0" width="'+width1+'" height="'+height+'" style="fill:'+color1+'"/>\n'
       var x= width1
      xmlsrc= xmlsrc+'<rect x="'+x+'" y="0" width="'+width2+'" height="'+height+'" style="fill:'+color2+'"/>\n'
          x= width1+width2
      xmlsrc= xmlsrc+'<rect x="'+x+'" y="0" width="'+width3+'" height="' +height+'" style="fill:'+color3+'"/>\n'
    
      xmlsrc= xmlsrc+'</svg>'*/

   let svgData = `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
   <svg viewBox="0 0 500 100" class="chart">
  <polyline
     fill="none"
     stroke="#0074d9"
     stroke-width="3"
     points="
       0,120
       20,60
       40,80
       60,20"/>
</svg>`; 
 
  xmlsrc= '';
     
     console.log('here  $scope.view.wdg['+imgWidget+'].src=')
     console.warn('data:image/svg+xml;base64,'+xmlsrc)
      
  $scope.view.wdg[imgWidget].imgsrc='data:image/svg+xml;base64,'+btoa(svgData);
}
//=============================================================================
function proportionalBar() {
  var imgWidget=''
  var height=30
  var color ='red'
   var width=0
   var x=0
   var firstWidth=0
   var xmlsrc_in=''
    var xmlsrc=    '<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n'
  
  if(arguments.length>0) imgWidget=arguments[0]
  if(arguments.length>1)  height=arguments[1]
  if(arguments.length>2) 
   
    console.log ("number of arguments ="+ arguments.length)
    
   for (var  i= 2; i < arguments.length; i++) 
   {
    console.log('Argument ['+i+']='+arguments[i]);
     if ( i % 2 == 0)
     { color =arguments[i] 
       console.log('color='+color)}
     else
     {
     if(firstWidth ==0) {firstWidth++
                         x=0
                         width=arguments[i]
                         console.log('width='+width)
                        }
       else            { width=arguments[i]
                         console.log('width='+width)
                         x=x+arguments[i-2]
                          console.log('x='+x)
                       
                         
                        }
           xmlsrc_in = xmlsrc_in+'<rect x="'+x+'" y="0" width="'+width+'" height="'+height+'" style="fill:'+color+'"/>\n'
           console.log('xmlsrc_in='+xmlsrc_in)
       
       
        }
     
   } 
  
  width= width+x
  
      xmlsrc= xmlsrc+'<svg xmlns="http://www.w3.org/2000/svg" height="'+height+'" width="'+ width+'">\n'
      xmlsrc= xmlsrc+ xmlsrc_in
    
      xmlsrc= xmlsrc+'</svg>'
   let svgData = `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
  <svg 
    id="svg1" 
    crossorigin="anonymous"
    xmlns="http://www.w3.org/2000/svg" 
    xmlns:xlink="http://www.w3.org/1999/xlink" 
    xmlns:xhtml="http://www.w3.org/1999/xhtml"
    width="600" height="500" >
  <polyline
     fill="none"
     stroke="#0074d9"
     stroke-width="3"
     points="
       0,120
       20,60
       40,80
       60,20
       80,120
       100,60
       120,80
       140,20
       160,120
       180,60
       200,80
       220,20"/>
         <polyline
     fill="none"
     stroke="#FFA500"
     stroke-width="3"
     points="
       0,10
       20,20
       40,60
       60,80
       80,20
       100,120
       120,60
       140,80
       160,20
       180,120
       200,60
       220,80"/>
       
         <polyline
     fill="none"
     stroke="#FF0000"
     stroke-width="3"
     points="
       0,60
       20,80
       40,20
       60,120
       80,60
       100,80
       120,20
       140,120
       160,60
       180,80
       200,20
       220,120"/>
</svg>`; 
     
  console.warn(xmlsrc);
  //$scope.view.wdg[imgWidget].imgsrc='data:image/svg+xml;base64,'+btoa(xmlsrc);
 $scope.view.wdg[imgWidget].src='data:image/svg+xml;base64,'+btoa(svgData);
  
}
//========================================================================
function drawGauge() {
  var imgWidget=''
  
  var xmlsrc_in=''
  var xmlsrc=    '<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n'
  var percent1=0
  var percent2=0
  var radius=150
  
  if(arguments.length>0) imgWidget=arguments[0]
  console.log("imgWidget="+imgWidget)
  if(arguments.length>1)  percent1=arguments[1]
  if(arguments.length>2)  percent2=arguments[2]
  if(arguments.length>3)  radius= parseInt(arguments[3])
  
  var width= 2.25*radius
  var height=2.25*radius
   
    console.log ("number of arguments ="+ arguments.length)
    
   for (var  i= 2; i < arguments.length; i++) 
   {
    console.log('Argument ['+i+']='+arguments[i]);
     
     
     var circumref= Math.floor(2*radius*Math.PI )
    
    
   
             xmlsrc_in = xmlsrc_in+ '<circle id="ground" r="'+ radius+'" cx="50%" cy="50%"></circle>\n'
             xmlsrc_in = xmlsrc_in+ '<circle id="low" r="'+ radius+'" cx="50%" cy="50%" stroke="#FDE47F" stroke-width="'+Math.floor(30*radius/150)+'" fill="none"></circle>\n'
             var angle= parseInt(percent1)*360/100
             var circumref_in= Math.floor(2*radius*Math.PI*angle/360)
             xmlsrc_in = xmlsrc_in+  '<circle id="avg" r="'+ radius+'" cx="50%" cy="50%" stroke="#7CCCE5" stroke-width="'+Math.floor(30*radius/150)+'" stroke-dasharray="'+ circumref_in+', '+ circumref+'" fill="none"></circle>\n'
             xmlsrc_in = xmlsrc_in+  '<text x="'+Math.floor( width/2-30*radius/150)+'" y="'+Math.floor(height/2-25*radius/150)+'" style="fill:#7CCCE5;" font-size="'+Math.floor(60*radius/150)+'"> '+percent1+'%</text>\n'
             var angle= parseInt(percent2)*360/100
             var circumref_in= Math.floor(2*radius*Math.PI*angle/360)
             xmlsrc_in = xmlsrc_in+  '<circle id="avg" r="'+ radius+'" cx="50%" cy="50%" stroke="#E04644" stroke-width="'+Math.floor(30*radius/150)+'" stroke-dasharray="'+ circumref_in+', '+ circumref+'" fill="none"></circle>\n'
             xmlsrc_in = xmlsrc_in+  '<text x="'+Math.floor( width/2-30*radius/150)+'" y="'+Math.floor(height/2+35*radius/150)+'" style="fill:#E04644;" font-size="'+Math.floor(60*radius/150)+'"> '+percent2+'%</text>\n'
       
   } 
  
 // width= width+x
  
      xmlsrc= xmlsrc+'<svg xmlns="http://www.w3.org/2000/svg" height="'+height+'" width="'+ width+'">\n'
      xmlsrc= xmlsrc+ xmlsrc_in
    
      xmlsrc= xmlsrc+'</svg>'
  console.warn(xmlsrc);
    console.warn( 'imgWidget='+imgWidget);
$scope.view.wdg[imgWidget].src='data:image/svg+xml;base64,'+btoa(xmlsrc);
    
  
}
//========================================================================
$rootScope.$on("modelLoaded", function() {
  
$timeout(proportionalBar('3DImage-1',60,'red',126,'green',300,'magenta',77,'yellow',100),1000)

console.log("modelLoaded started");
  
  
   $interval(function() {
    $scope.app.params['percent1'] =Math.floor( Math.random()*100);
    $scope.app.params['percent2'] =Math.floor( Math.random()*100);
    $timeout(drawGauge('3DImage-2',parseInt($scope.app.params['percent1']),parseInt($scope.app.params['percent2']),'50'),500) 
          }, 3500); 
     
 
  $timeout(drawGauge('3DImage-2','25','60','50'),1000) 
   
})
        



//$scope.$on('$ionicView.afterEnter', function()  {});

  
