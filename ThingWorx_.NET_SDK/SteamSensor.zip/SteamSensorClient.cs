﻿//using log4net;
using com.thingworx.communications.client;
using com.thingworx.communications.client.things;
using com.thingworx.communications.common;
using System;
using System.Threading;
using System.Reflection;
//using log4net.Config;
using System.IO;
using System.Runtime.InteropServices;

using static com.thingworx.communications.common.SecurityClaims;
using System.Linq;

// Refer to the "Steam Sensor Example" section of the documentation
// for a detailed explanation of this example's operation 
namespace SteamSensorConsole
{
    public class SteamSensorClient : ConnectedThingClient
    {
        //private static ILog  LOG = LogManager.GetLogger(typeof(SteamSensorClient));

        public SteamSensorClient(ClientConfigurator config) 
            : base(config)
        {
	    }

        private void startClient(object state)
        {
            start();
        }

        private void runClient(object state)
        {
            // Loop over all the Virtual Things and process them
            foreach (VirtualThing thing in getThings().Values)
            {
                try
                {
                    thing.processScanRequest();
                }
                catch (Exception eProcessing)
                {
                    Console.WriteLine("Error Processing Scan Request for [" + thing.getName() + "] : " + eProcessing.Message);
                }
            }
        }

        static void Main(string[] args)
        {
            //if(args.Length < 3) 
            //{
			    Console.WriteLine("Required arguments not found!");
			    Console.WriteLine("URI AppKey ScanRate");
			    Console.WriteLine("Example:");
            //    Console.WriteLine("SteamSensorClient.exe wss://localhost:443/Thingworx/WS xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx 1000");
            //return;
            //}
            


            // Establish logging if App.config is not supported as in .NET Core
#if TW_DOTNET_CORE
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            string logFilePath = Path.Combine(Directory.GetCurrentDirectory(), "log4net.config");
            var ret = XmlConfigurator.Configure(logRepository,new FileInfo(logFilePath));
#endif
            // Application key to connect to the Thingworx instance
            //var appKey = args[1];
            var appKey = "b20bb01d-1157-4bda-8fe1-124b8f7c6fc3";

            // The app key callback function is called whenever the SDK requires the current app key to authenticate
            // This example pulls the appkey from the command line arguments
            // In production, this callback should obtain an app key from a secure source.
            TwPasswordDelegate appKeyCallback = (password, maxLength) =>
            {
                string safePassword = appKey;
                if (safePassword.Length > maxLength - 1)
                {
                    safePassword = safePassword.Substring(0, maxLength - 1);
                }
                IntPtr stringPointer = (IntPtr)Marshal.StringToHGlobalAnsi(safePassword);
                twCopyMemory(password, stringPointer, (uint)safePassword.Length);
                Marshal.FreeHGlobal(stringPointer);
            };

            // Set the required configuration information
            var config = new ClientConfigurator
            {
                // Set the size of the threadpools
                MaxMsgHandlerThreadCount = 8,
                MaxApiTaskerThreadCount = 8,

                /***** WARNING: For Development purposes only. Do not use these settings in a production environment. *****/
                //config.AllowSelfSignedCertificates = true;
                DisableCertValidation = true,
                /***** WARNING *****/

                // The uri for connecting to Thingworx
                //Uri = args[0],
                Uri = "wss://pp-2112050711xm.portal.ptc.io:443/Thingworx/WS",

                // Reconnect every 15 seconds if a disconnect occurs or if initial connection cannot be made
                ReconnectInterval = 15,

                // Give the appKeyCallback function to the ClientConfigurator's Claims object, to use as needed
                Claims = SecurityClaims.fromAppKeyCallback(appKeyCallback),

                // Set the name of the client
                Name = "SteamSensorGateway",

                // Put the offline message store into a writable directory
                OfflineMsgStoreDir = Environment.CurrentDirectory = Environment.GetEnvironmentVariable("userprofile")
            };

            config.Claims.ToString();

            config.ServerCertFileInfo = new CertFileInfo();
            config.ServerCertFileInfo.FilePath = "C:/Users/Administrator/Downloads/TwxEducationSSL/_.portal.ptc.io.cer";
            config.AllowSelfSignedCertificates = true;
            config.AutoReconnect = true;
            config.ReconnectInterval = 5000;
            //config.DisableCertValidation = true;
            //config.setAsSDKType();
            config.ignoreSSLErrors(true);

            // Get the scan rate (milliseconds) that is specific to this example
            // The example will execute the processScanRequest of the VirtualThing
            // based on this scan rate
            //int scanRate = Int32.Parse(args[2]);
            int scanRate = 10000;
            // Create the client passing in the configuration from above
            SteamSensorClient client = new SteamSensorClient(config);

            try
            {
                // Create two Virtual Things 
                SteamThing sensor1 = new SteamThing("SteamSensor1", "1st Floor Steam Sensor", null, client);
                //SteamThing sensor2 = new SteamThing("SteamSensor2", "2nd Floor Steam Sensor", "SN0002", client);

                // Bind the Virtual Things
                client.bindThing(sensor1);
                //client.bindThing(sensor2);

                /***** WARNING: For Development purposes only. Do not use these settings in a production environment. *****/
                // To connect to an insecure (non-SSL) server
                //ConnectedThingClient.disableEncryption();
                /***** WARNING *****/

                
                // Start the client
                ThreadPool.QueueUserWorkItem(client.startClient);
            }
            catch (Exception eStart)
            {
                Console.WriteLine("Initial Start Failed : " + eStart.Message);
            }

            
            // Wait for the SteamSensorClient to connect, then process its associated things.
            // As long as the client has not been shutdown, continue
            while (!client.isShutdown())
            {
                // Only process the Virtual Things if the client is connected
                if (client.isConnected())
                {
                    ThreadPool.QueueUserWorkItem(client.runClient);
                }
                
                // Suspend processing at the scan rate interval
                Thread.Sleep(scanRate);
            }
        }
    }
}
