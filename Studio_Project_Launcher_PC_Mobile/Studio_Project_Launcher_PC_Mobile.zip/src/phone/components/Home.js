// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available
var IsVuforiaView = false;
if(navigator.userAgent.match(/(iPhone|iPad|Android.*Mobile)/i)){
  IsVuforiaView = true;
}
//alert(navigator.userAgent);

$scope.filterDatas = function(datas, name) {
  var list = [];
  for (var i=0; i<datas.length; i++) {
    if (datas[i].name.includes(name)) list.push(datas[i]);
  }
  return list;
}

$scope.getProjects = function() {
  $http.get('/ExperienceService/content/projects/', {
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      "Accept": "application/json",
      "Content-Type": "application/json"
    }
  }).then(function(resp){
    //_.set($scope.app, 'app.mdl.experienceService.svc.getProjects.data', {rows: resp.data});
    var groupDatas = null;
    var group = $scope.app.params.Group;
    if (group == 1) {
      groupDatas = $scope.filterDatas(resp.data, 'cam');
    } else if (group == 2) {     
      groupDatas = $scope.filterDatas(resp.data, 'tbs');
    } else {
      groupDatas = resp.data;
    }
    //alert(JSON.stringify(groupDatas));
    $scope.setWidgetProp('dataGrid-1', 'data', groupDatas);
    // console.log(JSON.stringify(resp.data));
    $scope.$applyAsync();
    // console.log("done getting projects", resp);
  }, function(err) {
    console.log('error getting projects', err);
  });
};

$scope.getProjects();

$scope.open = function (item, el) {
  if (IsVuforiaView) {
  	var pjtUrl = "http%3A%2F%2Fpp-2401181220lm.portal.ptc.io%2FExperienceService%2Fcontent%2Fprojects%2F" + item.name;
  	//var pjtUrl = "%2FExperienceService%2Fcontent%2Fprojects%2F" + item.name;
    //alert(pjtUrl);
  	window.location="vuforiaview://ptc.com/command/view-experience?url=" + pjtUrl;  
  } else {
    var pjtUrl = "http://localhost:3000/resource/" + item.name + "/dist/index-desktop.html?preview=true&project=" + item.name;
    //var pjtUrl = "https://apac.studio-trial.thingworx.io/resource/" + item.name + "/dist/index-desktop.html?preview=true&project=" + item.name;
    window.location = pjtUrl;  
  }
};
