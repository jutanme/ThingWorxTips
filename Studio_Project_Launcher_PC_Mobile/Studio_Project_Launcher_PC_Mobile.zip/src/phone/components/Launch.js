// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


$scope.selectGroup = function (group) {
  $scope.app.params.Group = group;
  $scope.app.fn.navigate('Home');
};