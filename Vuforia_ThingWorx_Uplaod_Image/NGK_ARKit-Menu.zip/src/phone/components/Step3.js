// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

//ページ遷移
$scope.movePage = function(page) {
  $scope.app.fn.navigate(page);
};

//操作時刻保存
$scope.saveAction = function(name) {
  var serviceName = 'UpdateActionDate';
  var parameters = {'ID': $scope.app.params['UID'],'name': name}; //input parameters object 
  twx.app.fn.triggerDataService($scope.app.params['TWXmodelID'], serviceName, parameters);
};