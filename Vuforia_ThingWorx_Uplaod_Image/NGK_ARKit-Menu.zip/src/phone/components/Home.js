// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

var MENU = {"Step1":"Menu_OilChange","Step2":"Menu_MorterNoise","Step3":"Menu_MorterSpeed","Step4":"Menu_SensorSense"}
var PAGE = "";

//ページ遷移
$scope.movePage = function(pageStr) {
  PAGE = pageStr;
  if ($scope.app.params['UID'] && $scope.app.params['UID'].length>5) {
    //$scope.saveAction();    
  	$scope.app.fn.navigate(PAGE);
  } else {
    //ID取得 
  	var serviceName = 'GetLastUID';    
  	twx.app.fn.triggerDataService($scope.app.params['TWXmodelID'], serviceName, {});
  }
};

//ID取得 イベント
$scope.$on('GetLastUID.serviceInvokeComplete', function(evt, arg) {
  $scope.app.params['UID'] = $scope.app.mdl[$scope.app.params['TWXmodelID']].svc['GetLastUID'].data[0].result;
//  $scope.saveAction();
});


//新規作成
$scope.createNew = function() {  
  var serviceName = 'CreateAdjustData';    
  twx.app.fn.triggerDataService($scope.app.params['TWXmodelID'], serviceName, {});
};
//新規作成 イベント
$scope.$on('CreateAdjustData.serviceInvokeComplete', function(evt, arg) {
  $scope.app.params['UID'] = $scope.app.mdl[$scope.app.params['TWXmodelID']].svc['CreateAdjustData'].data[0].result;
  PAGE = "Step1";
  $scope.app.fn.navigate(PAGE);
});

//操作時刻保存
$scope.saveAction = function(name) {
  var serviceName = 'UpdateActionDate';
  var parameters = {'ID': $scope.app.params['UID'],'name': name}; //input parameters object 
  twx.app.fn.triggerDataService($scope.app.params['TWXmodelID'], serviceName, parameters);
};

//操作時刻保存後ページ遷移
$scope.$on('UpdateActionDate.serviceInvokeComplete', function(evt, arg) {
  $scope.app.fn.navigate(PAGE);
});