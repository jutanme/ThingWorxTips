// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available
//console.log("UID: " + $scope.app.params['UID']);

//ページ遷移
$scope.movePage = function(page) {
  $scope.app.fn.navigate(page);
};

//限度見本
$scope.showSample = function() {
  var visible = $scope.getWidgetProp('popup-1','visible') == 'true' ? 'false' : 'true';
  $scope.setWidgetProp('popup-1','visible', visible);
};

//画像アップロード 
$scope.sendImage = function() {
  $scope.setWidgetProp('label-3','text', "画像アップロード開始");
  $scope.setWidgetProp('popup-2','visible', 'true');
  var serviceName = 'UploadPicture';
  var parameters = {'ID': $scope.app.params['UID'],'Image': $scope.getWidgetProp('camera-1','image')}; //input parameters object 
  twx.app.fn.triggerDataService($scope.app.params['TWXmodelID'], serviceName, parameters);
};

//画像アップロード成功
$scope.$on('UploadPicture.serviceInvokeComplete', function(evt, arg) {
  var imagePath = $scope.app.mdl[$scope.app.params['TWXmodelID']].svc['UploadPicture'].data[0].result;
  $scope.setWidgetProp('label-3','text', imagePath + "へアップロードしました");
  $scope.setWidgetProp('popup-2','visible', 'true');
  $timeout(function () {
    $scope.setWidgetProp('popup-2','visible', 'false');
  }, 3000);
});

//画像アップロード失敗
$scope.$on('UploadPicture.serviceFailure', function(evt, arg) {
  $scope.setWidgetProp('label-3','text', "画像のアップロードが失敗しました");
  $scope.setWidgetProp('popup-2','visible', 'true');
  $timeout(function () {
    $scope.setWidgetProp('popup-2','visible', 'false');
  }, 3000);
});

//操作時刻保存
$scope.saveAction = function(name) {
  var serviceName = 'UpdateActionDate';
  var parameters = {'ID': $scope.app.params['UID'],'name': name}; //input parameters object 
  twx.app.fn.triggerDataService($scope.app.params['TWXmodelID'], serviceName, parameters);
};


