// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

//ページ遷移
$scope.movePage = function(page) {
  $scope.app.fn.navigate(page);
};
