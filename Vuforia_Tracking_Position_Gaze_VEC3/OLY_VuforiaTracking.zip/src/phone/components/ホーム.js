// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

/* 定数 */
const validationMax1000ValueMessage = '1から1000の整数を入力してください。'
const validationMax359ValueMessage = '1から359の整数を入力してください。'
const modelTooSmallMessage = 'これ以上モデルを縮小できません。'
const modelTooBigMessage = 'これ以上モデルを拡大できません。'
const errorChangeFigureMessage = 'プレイ中は操作できません。'

const blinkingOneWayMarkInterval = 750; // milliseconds
const opacitySpan = 0.14285;

const modelID = 'mainModel'; // シーケンス再生をする 3DモデルのId

/* 変数 */
var moveValue = 100; // mm
var expandValue = 10; // %
var rotationValue = 10; //°
var visiblePopup = false;

var cameraPosition = null;
var cameraGaze = null;
var movableObjects = [];
// var movablePoints = [];
var oneWayMarkTimerId = -1;
var modelTimerID = -1;

var opacityValue1 = 0.14;
var opacityValue2 = 0.28;
var opacityValue3 = 0.42;
var opacityValue4 = 0.56;
var opacityValue5 = 0.7;
var opacityValue6 = 0.84;
var opacityValue7 = 0.99;

var nowOffsetX = 0.0;
var nowOffsetY = 0.0;
var nowOffsetZ = 0.0;
var nowRotation = 0.0;
var nowScale = 1.0;

/* クラス */
class Vector {
    constructor() {
		this.x = 0;
        this.y = 0;
        this.z = 0;
	}
  SetX(value) {
    this.x = value;
  }
  GetX() {
    return this.x;
  }
  
  SetY(value) {
    this.y = value;
  }
  GetY() {
    return this.y;
  }
  
  SetZ(value) {
    this.z = value;
  }
  GetZ(){
    return this.z;
  }
}

cameraPosition = new Vector();
cameraGaze = new Vector();

/* イベント */
$scope.$on('tracking', function(evt, arg){
  if (!cameraPosition || !cameraGaze) return;
  cameraPosition.SetX(arg.position[0]);
  cameraPosition.SetY(arg.position[1]);
  cameraPosition.SetZ(arg.position[2]);
  cameraGaze.SetX(arg.gaze[0]);
  cameraGaze.SetY(arg.gaze[1]);
  cameraGaze.SetZ(arg.gaze[2]);
  //console.log(cameraPosition + " ====================== " + cameraGaze);
  $rootScope.SaveTracking(cameraPosition,cameraGaze);
});

$rootScope.SaveTracking = function(posi, gaze) {
  twx.app.fn.triggerDataService("OLY.VuforiaVec3.TH", 'SaveVec3', {"posi" : posi, "gaze" : gaze});
};





