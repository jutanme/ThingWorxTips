// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

//モデル名
var SEQ_MODEL = "model-1", ARROW_Y = 0.1, LBL_SCALE=0.5, WP_Start, WP_End;

var WayDataORG, intervalWP, timeNext=3000;

//ステップ情報リスト
var STEP_LIST = {
  "step1":{"wp":[0,0],"im":"","lb":""},
  "step2":{"wp":[1,1],"im":"","lb":""},
  "step3":{"wp":[2,3],"im":"","lb":"step3 TEST"},
  "step4":{"wp":[4,9],"im":"3DImage-2","lb":"step4 TEST"},
  "step5":{"wp":[10,10],"im":"","lb":""},
  "step6":{"wp":[11,15],"im":"","lb":""},
  "step7":{"wp":[16,17],"im":"","lb":""},
  "step8":{"wp":[18,19],"im":"","lb":""},
  "step9":{"wp":[0,0],"im":"","lb":""}
};                          

          
//再生
$scope.playStarted = function(){
  var currentStep = $scope.getWidgetProp(SEQ_MODEL,'currentStep');

  // TODO rotate model
  //ラベル非表示   
  $scope.hide();
        
  //ラベル表示  
  $scope.show(currentStep, true);
  //WPの座標更新
  //intervalWP = setInterval($scope.moveWP, 100);
};

//停止
$scope.playStopped = function(){
  //clearInterval(intervalWP);
};

//ラベル非表示   
$scope.hide = function(){
  $scope.view.wdg["3DLabel-1"]["visible"] = false;
  $scope.view.wdg["3DImage-2"]["visible"] = false;
};

//ラベル表示 
$scope.show = function(currentStep, isNext){
  //ステップ情報 
  var stepInfo = STEP_LIST["step" + currentStep];
  //console.log("stepInfo: " + JSON.stringify(stepInfo));

  WP_Start = stepInfo.wp[0];
  WP_End = stepInfo.wp[1];
  $scope.setWidgetProp('wayfinder-1','selectedWaypointIndex', WP_Start);
  //ラベル表示
  if (stepInfo.lb) {
    $scope.view.wdg["3DLabel-1"]["text"] = stepInfo.lb;
    $scope.view.wdg["3DLabel-1"]["visible"] = true;
  }
  //画像表示
  if (stepInfo.im && stepInfo.im.length>0) {
    $scope.view.wdg[stepInfo.im]["visible"] = true;
  }
  //次のWPへ
  var cnt = WP_End - WP_Start;
  if (isNext && cnt>0) {
    $scope.nextWPAuto(currentStep);
  }
};

//設定（ウェイファインダ）
$scope.setStep = function(){
  $timeout(function () {
  	var currentStep = $scope.getWidgetProp(SEQ_MODEL,'currentStep');
    // TODO rotate model
    //ラベル非表示   
    $scope.hide();        
    //ラベル表示  
    $scope.show(currentStep, false);
  }, 300);
};

//前へ（ウェイファインダ）
$scope.prevWP = function(){
  var idx = $scope.getWidgetProp('wayfinder-1','selectedWaypointIndex');
  //console.log("wp idx: " + idx);
  if (WP_Start<idx) {
    $scope.setWidgetProp('wayfinder-1','selectedWaypointIndex', (idx-1));
  }
};

//次へ（ウェイファインダ）
$scope.nextWP = function(){
  var idx = $scope.getWidgetProp('wayfinder-1','selectedWaypointIndex');
  if (WP_End>idx) {
    console.log("nextWP: " + idx);
    $scope.setWidgetProp('wayfinder-1','selectedWaypointIndex', (idx+1));
  }
};

//初期処理
$timeout(function () {
  $scope.view.wdg["3DLabel-1"]["scale"] = LBL_SCALE;
  WayDataORG = $scope.view.wdg["wayfinder-1"]["waypointsData"];
  //console.log("wayData: " + JSON.stringify(wayData));
  $scope.setWidgetProp('wayfinder-1','selectedWaypointIndex', 0);
}, 3000);


//次のWPへ（自動）
$scope.nextWPAuto = function(currentStep){
  switch (currentStep) {
    case 3:
      $timeout(function () {
        $scope.nextWP();
      }, timeNext);
      break;
    case 4:      
      $timeout(function () {
        $scope.nextWP();        
        $timeout(function () {
          $scope.nextWP();
          $timeout(function () {
            $scope.nextWP();
            $timeout(function () {
              $scope.nextWP();
              $timeout(function () {
                $scope.nextWP();
              }, timeNext);
            }, timeNext);
          }, timeNext);
        }, timeNext);
      }, timeNext);
      break;      
    case 6:      
      $timeout(function () {
        $scope.nextWP();        
        $timeout(function () {
          $scope.nextWP();
          $timeout(function () {
            $scope.nextWP();
            $timeout(function () {
              $scope.nextWP();
            }, timeNext);
          }, timeNext);
        }, timeNext);
      }, timeNext);
      break;  
    case 7:
      $timeout(function () {
        $scope.nextWP();
      }, timeNext);
      break;
    case 8:
      $timeout(function () {
        $scope.nextWP();
      }, timeNext);
      break;
    default:
      // Do Nothing
  }
};






















//WPの座標更新
$scope.moveWP = function(){
  //$scope.setWidgetProp('waypoint-1','x', $scope.view.wdg["modelitem-1"]["x"]);
  //wayData[5].position.x = $scope.view.wdg["modelitem-1"]["x"];
  //var locX = tml3dRenderer.GetObject('model-1-/0/0/17').GetWidget().GetLocation().position.x;
  //var locY = tml3dRenderer.GetObject('model-1-/0/0/17').GetWidget().GetLocation().position.y;
  //var locZ = tml3dRenderer.GetObject('model-1-/0/0/17').GetWidget().GetLocation().position.z;
  //console.log("moveWP: x " + locX +" y " + locY + " z " + locZ);
  //WayDataORG[4].position.x = -0.163;
  //WayDataORG[4].position.y = locY;
  //WayDataORG[4].position.z = 0.255;
  //$scope.setWidgetProp('wayfinder-1','waypointsData', WayDataORG);
  var wayData = $scope.view.wdg["wayfinder-1"]["selectedWaypointData"];
  if (wayData && wayData.rows) {
    var modelLoc = tml3dRenderer.GetObject('model-1-/0/0/11').GetWidget().GetLocation();
    wayData.rows[0].position.x = modelLoc.position.x;
    wayData.rows[0].position.y = modelLoc.position.y;
    wayData.rows[0].position.z = modelLoc.position.z;
  }
};

