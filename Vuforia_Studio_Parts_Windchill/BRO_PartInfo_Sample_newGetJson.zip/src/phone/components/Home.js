// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


//Define Constants used in Script
var PICK_COLOR = "rgba(0,255,0,1)"; //sets color to selected part
var MODEL_JSON = {'ModelSample':'ar_sample_asm.metadata.json'}; //variable to set JSON schema for part identification

//Define Needed Arrays
$scope.modelData = [];
var idpath ="";
//Touch and Part ID
$timeout( function(){
  angular.forEach($element.find('twx-dt-model'), function(value, key) {
    angular.element(value).scope().$on('userpick',function(event,target,parent,edata) {
      //var idpath = JSON.parse(edata).occurrence;
      idpath = JSON.parse(edata).occurrence;
      var data = $scope.modelData [target];

      if (data != undefined){
        if(edata != "" && $scope.currentSelection != undefined){
          tml3dRenderer.setColor($scope.currentSelection, undefined);
        }
        idpath = "/0/0";
        if (edata != "") {
          idpath = JSON.parse(edata).occurrence;
        }
        $scope.currentSelection = target + "-" + idpath;
        tml3dRenderer.setColor($scope.currentSelection, PICK_COLOR);
        var pname = data[idpath]["__PV_SystemProperties"]["Part Name"];
        if (pname == undefined || pname == ""){
          pname = idpath;
        }
		$scope.currentSelection.visible = false;
		// Added by SCLee
        //tml3dRenderer.setProperties($scope.currentSelection,{ hidden:true });
		//alert(edata+","+pname);
        
        // Get Windchill Part Name
        twx.app.fn.triggerDataService( 'BRO.ARSample.TH', 'GetPartInfo', {"PTC_WM_NUMBER":pname});

  		$scope.$on('GetPartInfo.serviceInvokeComplete', function(evt, arg) {
    	  var result = $scope.app.mdl['BRO.ARSample.TH'].svc['GetPartInfo'].data.current['result'];
          //alert(result);
          var json = JSON.parse(result);
          $scope.view.wdg['label-16'].text = json.PARTNAME;
          $scope.view.wdg['label-18'].text = json.PARTCODE;
          $scope.view.wdg['label-20'].text = json.MATERIAL;
          $scope.view.wdg['label-22'].text = json.WORKINGPROCESS;
          $scope.view.wdg['label-24'].text = json.MODIFIDATE;
          $scope.view.wdg['label-26'].text = json.REVISION;
          $scope.view.wdg['hyperlink-2'].url = json.WCLINK;
  		});
      }
    });
  });
}, 0);


angular.forEach(MODEL_JSON, function(value, key) {
  $http.get('app/resources/Uploaded/' + value).
  success(function(data,status,headers,config){
    $scope.modelData [key] = data;
  })
    .error(function(data,status,headers,config){
  });
});



$scope.TestTWXService = function(pname) {
  twx.app.fn.triggerDataService( 'BRO.ARSample.TH', 'GetPartInfo', {"PTC_WM_NUMBER":pname});
  $scope.$on('GetPartInfo.serviceInvokeComplete', function(evt, arg) {
  alert(1);
    var wcPartName = $scope.app.mdl['BRO.ARSample.TH'].svc['GetPartInfo'].data.current['result'];
    alert(wcPartName);
	//$scope.setWidgetProp('label-9', 'text', wcPartName);
  });
}




$scope.getProperty2 = function(){
	let metaDATA=PTC.Metadata.fromId('ModelSample');
	
    metaDATA.then(function(meta) {  
		console.log("success func of metaData");
       var number = meta.get(idpath,"PTC_WM_NUMBER");
      $scope.app.params.text = number;
      
    }) .catch(function(err) {
   		console.log("problem with the read of metadata ");
   		console.warn(err);
 	});  
}

/*

$scope.$on('userpick', function(event, targetName, targetType, eventData) {
  
  try {
      var pathid = JSON.parse(eventData).occurrence;
      //$scope.app.params.CURRENT_PATHID = pathid;

      PTC.Metadata.fromId("modelMain").then((metadata) => {
        var displayName = metadata.get(pathid, 'PTC_WM_NUMBER');
        doPopup(displayName, pathid);

     });
    
  } catch (err) {
     console.log(err);
    
  }

});
*/