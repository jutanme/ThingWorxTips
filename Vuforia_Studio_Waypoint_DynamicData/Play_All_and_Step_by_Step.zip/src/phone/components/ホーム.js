// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

//アプリケーションパラメータ playStep
// ↑ モデルの currentStep が play で自動的に +1 されるため保持用のパラメータ
//
// ステップ移動は各ステップの「再生前」の状態



var wdata = [{"position":{"x":-0.5982,"y":0.1157,"z":0.0038},"gaze":{"x":0,"y":0,"z":-1},"up":{"x":0,"y":1,"z":0},"eventRadius":0.25,"wayfinderDisplayBoundary":0.5,"label":"Waypoint 1","$$hashKey":"object:192"},{"position":{"x":-0.0134,"y":0.3798,"z":-0.0517},"gaze":{"x":0,"y":0,"z":-1},"up":{"x":0,"y":1,"z":0},"eventRadius":0.25,"wayfinderDisplayBoundary":0.5,"label":"Waypoint 2","$$hashKey":"object:193"},{"position":{"x":0.1018,"y":0.0438,"z":-0.1376},"gaze":{"x":-0.7145947830396169,"y":-0.699538630850765,"z":-2.0816681711721685e-16},"up":{"x":0,"y":1,"z":0},"eventRadius":0.25,"wayfinderDisplayBoundary":0.5,"label":"Waypoint 3","$$hashKey":"object:194"},{"position":{"x":0.1897,"y":0.0208,"z":-0.2067},"gaze":{"x":0,"y":0,"z":-1},"up":{"x":0,"y":1,"z":0},"eventRadius":0.25,"wayfinderDisplayBoundary":0.5,"label":"Waypoint 4","$$hashKey":"object:195"},{"position":{"x":0.0962,"y":0.0919,"z":-0.1451},"gaze":{"x":-0.5224985567578407,"y":-0.8526401513676398,"z":-0.0001745329243134225},"up":{"x":0,"y":1,"z":0},"eventRadius":0.25,"wayfinderDisplayBoundary":0.5,"label":"Waypoint 5","$$hashKey":"object:196"}];

setTimeout(function() {
  $scope.setWidgetProp('wayfinder-1','waypointsData', wdata);
},1000);


//”すべて再生（中止されたらそのステップから）”
$scope.playAllStep = function() { 
 
 console.log(JSON.stringify($scope.getWidgetProp('wayfinder-1','waypointsData')));
 $scope.setWidgetProp('playButton','visible','false')
 $scope.setWidgetProp('pause','visible','true')

  $scope.setWidgetProp('wayfinder-1','showRibbon', 'true'); 
  $scope.setWidgetProp('wayfinder-1','showWaypoints', 'true');  
  $scope.setWidgetProp('wayfinder-1','showLabels', 'true');   
  $scope.setWidgetProp('waypoint-5','labelText', 'AAAAA');   
 setTimeout(function() {
    twx.app.fn.triggerWidgetService( 'model-1', 'playAll');
 },1000);
  
}

//”次のステップで中止”
$scope.pauseStep = function() { 
  
 $scope.setWidgetProp('playButton','visible','true')
 $scope.setWidgetProp('pause','visible','false')
  
 setTimeout(function() {
    twx.app.fn.triggerWidgetService( 'model-1', 'stop');
 },1000); 
}


//”そのステップのみ再生”
$scope.playStep = function() { 
 
 setTimeout(function() {
    twx.app.fn.triggerWidgetService( 'model-1', 'play');
 },1000);
  
}

//ステップ指定
$scope.setPlayStep = function(setstep) {
 $scope.app.params.playStep = setstep; 
 $scope.setCurrentstep();
}


//ボタンクリックで変更されたステップを再生ステップに反映
$scope.setCurrentstep = function() {
  
 $scope.setWidgetProp('model-1','currentStep', $scope.app.params.playStep )
// $scope.setLabelButton() ;
}

/*
//ボタン表示の制御
$scope.setLabelButton = function() {

  var step =  $scope.app.params.playStep ;
    
 if ( step != $scope.view.wdg['model-1']['steps']  ) {
     $scope.setWidgetProp('playButton','visible','true')
 }
  
 if ( step == 1 ) {
     $scope.setWidgetProp('pause','visible','false')
 }
  
}
*/


//各ボタンで playStep の変更


//初期状態に戻る
$scope.resetStep = function() {
  
 $scope.app.params.playStep = 1 ;
 $scope.setCurrentstep();
 $scope.setWidgetProp('playButton','visible','true')
 $scope.setWidgetProp('pause','visible','false')

}

//最終状態まで送り（全ステップ数はモデル情報から取り込み）
$scope.endStep = function() {
  
 $scope.app.params.playStep = $scope.view.wdg['model-1']['steps'] ;
 $scope.setCurrentstep();

}

$scope.$watch("view.wdg['model-1'].currentStep", function(crntStep){ 
  $scope.setWidgetProp('wayfinder-1','selectedWaypointIndex', crntStep-1);
});