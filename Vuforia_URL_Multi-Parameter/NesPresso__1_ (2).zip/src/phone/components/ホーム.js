// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

/*$scope.testC = function 
  (
);*/


$scope.testScan = function() {
var value = $scope.getWidgetProp('scan-1','scannedValue');
  alert(value);
//['scan-1']['scannedValue'];
};


$scope.loadDeeplinkedExperience = function () {
  window.location="thingworxview://ptc.com/command/view-experience?url=" 
    + encodeURIComponent("http://192.168.1.45:2019/ExperienceService/content/projects/paramtest/index.html?bbb=1234&aaa=222") 
    + "&expIndex=0#/Home";
}


