﻿/* global TW, pdfjsLib */
$("body").append('<script type="text/javascript" src="../Common/extensions/Pie_Chart2/ui/Pie_Chart2/loader.js"></script>');

TW.Runtime.Widgets.piechart2 = function () {
    this.MAX_SERIES = 16;
    var widgetReference = this;

    this.dynamicSeries = undefined;
    
    this.selectedItems = [];
    
    this.needsManualResize = true;
    
	// Edit by PTCJ
	var widgetProperties;		
    this.afterRender = function () {
        widgetProperties = this.properties;
        this.drawPieChart();
    };

    this.updateProperty = function (updatePropertyInfo) {
        widgetProperties = this.properties;
        switch (updatePropertyInfo.TargetProperty) {
            case 'ChartTitle':
                this.setProperty('ChartTitle', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'LabelField':
                this.setProperty('SelectedFieldName', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'ValueField':
                this.setProperty('SelectedValueName', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'ShowLegend':
                this.setProperty('ShowLegend', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'Data':
                this.setProperty('Data', updatePropertyInfo.ActualDataRows);
                break;
            case 'Is3D':
                this.setProperty('Is3D', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'PieHole':
                this.setProperty('PieHole', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'BackgroundColor':
                this.setProperty('BackgroundColor', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'PieSliceText':
                this.setProperty('PieSliceText', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'LegendLocation':
                this.setProperty('LegendLocation', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'TitleTextStyle':
                this.setProperty('TitleTextStyle', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'LegendTextStyle':
                this.setProperty('LegendTextStyle', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'ChartArea':
                this.setProperty('ChartArea', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'Width':
                this.setProperty('Width', updatePropertyInfo.RawSinglePropertyValue);
                break;
            case 'Height':
                this.setProperty('Height', updatePropertyInfo.RawSinglePropertyValue);
                break;
            // case 'ChartColors':
            //     this.setProperty('ChartColors', updatePropertyInfo.RawSinglePropertyValue);
            //     break;
            default:
                break;
        }

        //if (updatePropertyInfo.TargetProperty === "CustomClass") {
        //    this.resize(widgetReference.jqElement.outerWidth(), widgetReference.jqElement.outerHeight());
        //}
        this.drawPieChart();
    };

    // this.resize = function(width,height) {
    //     this.chart.resize(width, height);
    // };

    this.renderHtml = function () {
        var html = '<div class="widget-content widget-piechart2-container svg-chrome-fix"></div>';
        return html;
    };
    
    // Edit by PTCJ
    this.drawPieChart = function (){
      google.charts.load("visualization", "1", {packages:["corechart"]});
      google.charts.setOnLoadCallback(this.drawChart);
    }
    this.drawChart = function () {
        var fieldName = widgetProperties['LabelField'];
        var fieldValue = widgetProperties['ValueField'];
        var dataRows = widgetProperties['Data'];
        var dataArr = [[fieldName, fieldValue]];
        if (dataRows && dataRows.length>0) {
            for (var i = 0; i < dataRows.length; i++) {
                var label = dataRows[i][fieldName];
                var value = dataRows[i][fieldValue];
                dataArr.push([label, value]);
            }
        }
        var data = google.visualization.arrayToDataTable(dataArr);
        var legendPo = (widgetProperties['ShowLegend'] == false) ? 'none' : widgetProperties['LegendLocation'];
        var options = {
            title: widgetProperties['ChartTitle'],
            width: widgetProperties['Width'],
            height: widgetProperties['Height'],
            pieSliceText: widgetProperties['PieSliceText'],
            is3D: widgetProperties['Is3D'],
            legend: {position: legendPo, textStyle: {color: 'blue', fontSize: 12}, alignment: 'center'}
        };
        if (widgetProperties['BackgroundColor']) {
            options.backgroundColor = widgetProperties['BackgroundColor'];
        }
        if (widgetProperties['PieHole']) {
            options.pieHole = widgetProperties['PieHole'];
        }
        if (widgetProperties['TitleTextStyle']) {
            options.titleTextStyle = JSON.parse(widgetProperties['TitleTextStyle']);
        }
        if (widgetProperties['LegendTextStyle']) {
            options.legend.textStyle = JSON.parse(widgetProperties['LegendTextStyle']);
        }
        if (widgetProperties['ChartArea']) {
            options.chartArea = JSON.parse(widgetProperties['ChartArea']);
        }
        //if (widgetProperties['ChartColors']) {
        //    options.colors = JSON.parse(widgetProperties['ChartColors']);
        //}
        var chart = new google.visualization.PieChart(document.getElementById(widgetReference.jqElementId));
        chart.draw(data, options);
    }

};

