﻿TW.IDE.Widgets.piechart2 = function () {

    this.MAX_SERIES = 16;
    this.widgetIconUrl = function() {
        return  "'../Common/extensions/Pie_Chart2/ui/Pie_Chart2/piechart2.ide.png'";
    };
    this.widgetProperties = function () {
        var properties = {
            'name': TW.IDE.I18NController.translate('Pie_Chart2'),
            'description': TW.IDE.I18NController.translate('tw.piechart2-ide.widget.description'),
            'category': ['Data', 'Charts'],
            'supportsLabel': false,
            'supportsAutoResize': true,
            'borderWidth': 1,
            'defaultBindingTargetProperty': 'Data',
            'supportsTooltip': false,
            'properties': {
                // 'CustomClass': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.custom-class.description'),
                //     'baseType': 'STRING',
                //     'isLocalizable': false,
                //     'isBindingSource': true,
                //     'isBindingTarget': true,
                //     'isVisible': false
                // },
                // 'SingleDataSource': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.single-data-source.description'),
                //     'defaultValue': true,
                //     'baseType': 'BOOLEAN',
                //     'isVisible': false
                // },
                'Data': {
                    'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.data.description'),
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'LabelField': {
                    'baseType': 'FIELDNAME',
                    'isBindingTarget':false,
                    'sourcePropertyName': 'Data',
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.label-field.description')
                },
                'ValueField': {
                    'baseType': 'FIELDNAME',
                    'isBindingTarget':false,
                    'sourcePropertyName': 'Data',
                    'baseTypeRestriction': 'NUMBER',
                    'isVisible': true,
                    'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.value-field.description')
                },
                // 'ColorFormat': {
                //     'baseType': 'STATEFORMATTING',
                //     'baseTypeInfotableProperty': 'Data',    // which property's datashape to use and require being bound in order to configure the renderer, etc.
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.color-format.description')
                // },
                // 'ChartType': {
                //     'description': 'Type of chart',
                //     'baseType': 'STRING',
                //     'defaultValue': 'pie',
                //     'visible' : false
                // },
                // 'ChartOrientation': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.chart-orientation.description'),
                //     'baseType': 'STRING',
                //     'defaultValue': 'vertical',
                //     'isVisible' : false
                // },
                // 'ChartStyle': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.chart-style.description'),
                //     'baseType': 'STYLEDEFINITION',
                //     'defaultValue': 'DefaultChartStyle'
                // },
                // 'ChartAreaStyle': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.chart-area-style.description'),
                //     'baseType': 'STYLEDEFINITION',
                //     'defaultValue': 'DefaultChartAreaStyle'
                // },
                // 'ChartLegendStyle': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.chart-legend-style.description'),
                //     'baseType': 'STYLEDEFINITION',
                //     'defaultValue': 'DefaultChartLegendStyle'
                // },
                // 'ChartTitleStyle': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.chart-title-style.description'),
                //     'baseType': 'STYLEDEFINITION',
                //     'defaultValue': 'DefaultChartTitleStyle'
                // },
                // 'ChartIndicatorStyle': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.chart-indicator-style.description'),
                //     'baseType': 'STYLEDEFINITION',
                //     'defaultValue': 'DefaultChartIndicatorStyle'
                // },
                // 'SelectedItemStyle': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.selected-item-style.description'),
                //     'baseType': 'STYLEDEFINITION',
                //     'defaultValue': 'DefaultChartSelectionStyle'
                // },
                // 'CombineSelectedItemStyle': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.combine-selected-item-style.description'),
                //     'baseType': 'BOOLEAN',
                //     'defaultValue': false
                // },
                'ChartTitle': {
                    'description': TW.IDE.I18NController.translate('Text to display above the chart'),
                    'baseType': 'STRING',
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'isLocalizable': true
                },
                'ShowLegend': {
                    'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.show-legend.description'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': true
                },
                // 'LegendWidth': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-width.description'),
                //     'baseType': 'NUMBER',
                //     'defaultValue': 0
                // },
                // 'LegendLocation': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-location.description'),
                //     'baseType': 'STRING',
                //     'defaultValue': 'right',
                //     'selectOptions': [
                //         { value: 'right', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-location.select-options.right') },
                //         { value: 'top', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-location.select-options.top') },
                //         { value: 'bottom', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-location.select-options.bottom') },
                //         { value: 'left', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-location.select-options.left') }
                //     ]
                // },
                // 'LegendOrientation': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-orientation.description'),
                //     'baseType': 'STRING',
                //     'defaultValue': 'vertical',
                //     'selectOptions': [
                //         { value: 'vertical', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-orientation.select-options.vertical') },
                //         { value: 'horizontal', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.legend-orientation.select-options.horizontal') }
                //     ]
                // },
                // 'LabelFormat': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.label-format.description'),
                //     'baseType': 'STRING',
                //     'defaultValue' : ''
                // },
                // 'LabelType': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.label-type.description'),
                //     'baseType': 'STRING',
                //     'defaultValue': 'STRING',
                //     'selectOptions': [
                //         { value: 'STRING', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.label-type.select-options.string') },
                //         { value: 'NUMERIC', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.label-type.select-options.numeric') },
                //         { value: 'DATETIME', text: TW.IDE.I18NController.translate('tw.piechart2-ide.properties.label-type.select-options.date-time') }
                //     ]
                // },
                // 'ValueFormat': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.value-format.description'),
                //     'baseType': 'STRING',
                //     'defaultValue' : '0000.0'
                // },
                // 'AllowSelection': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.allow-selection.description'),
                //     'baseType': 'BOOLEAN',
                //     'isVisible': true,
                //     'defaultValue': true
                // },
                // 'EnableHover': {
                //     'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.enable-hover.description'),
                //     'baseType': 'BOOLEAN',
                //     'isVisible': true,
                //     'defaultValue': true
                // },
                'Width': {
                    'defaultValue': 640,
                    'baseType': 'NUMBER',
                    'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.width.description')
                },
                'Height': {
                    'defaultValue': 440,
                    'baseType': 'NUMBER',                    
                    'description': TW.IDE.I18NController.translate('tw.piechart2-ide.properties.height.description')
                },
                'Is3D': {
                    'description': TW.IDE.I18NController.translate('If true, displays a three-dimensional chart'),
                    'baseType': 'BOOLEAN',
                    'defaultValue': false
                },
                'PieHole': {
                    'description': TW.IDE.I18NController.translate('The pieHole option should be set to a number between 0 and 1'),
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
                'BackgroundColor': {
                    'description': TW.IDE.I18NController.translate('example: red or #00cc00'),
                    'baseType': 'STRING',
                    'defaultValue': 'transparent'
                },
                'LegendLocation': {
                    'description': TW.IDE.I18NController.translate('Position of the legend'),
                    'baseType': 'STRING',
                    'defaultValue': 'bottom',
                    'selectOptions': [
                        { value: 'right', text: TW.IDE.I18NController.translate('right') },
                        { value: 'top', text: TW.IDE.I18NController.translate('top') },
                        { value: 'bottom', text: TW.IDE.I18NController.translate('bottom') },
                        { value: 'left', text: TW.IDE.I18NController.translate('left') },
                        { value: 'labeled', text: TW.IDE.I18NController.translate('labeled') },
                        { value: 'none', text: TW.IDE.I18NController.translate('none') }
                    ]
                },
                'PieSliceText': {
                    'description': TW.IDE.I18NController.translate('The content of the text displayed on the slice'),
                    'baseType': 'STRING',
                    'defaultValue': 'value',
                    'selectOptions': [
                        { value: 'percentage', text: TW.IDE.I18NController.translate('percentage') },
                        { value: 'value', text: TW.IDE.I18NController.translate('value') },
                        { value: 'label', text: TW.IDE.I18NController.translate('label') },
                        { value: 'none', text: TW.IDE.I18NController.translate('none') }
                    ]
                },
                'TitleTextStyle': {
                    'description': TW.IDE.I18NController.translate('An object that specifies the title text style'),
                    'baseType': 'STRING',
                    'defaultValue': '{"color": "black", "fontName": "Arial", "fontSize": 16}'
                },
                'LegendTextStyle': {
                    'description': TW.IDE.I18NController.translate('An object that specifies the title text style'),
                    'baseType': 'STRING',
                    'defaultValue': '{"color": "black", "fontName": "Arial", "fontSize": 12}'
                },
                'ChartArea': {
                    'description': TW.IDE.I18NController.translate('Example: {"left":null,"top":null,"width":"70%","height":"70%"}'),
                    'baseType': 'STRING',
                    'defaultValue': '{"left":null,"top":null,"width":"80%","height":"80%"}'
                },
                // 'ChartColors': {
                //     'description': TW.IDE.I18NController.translate('The colors to use for the chart elements, for example: colors:["red","#004411"]'),
                //     'baseType': 'STRING',
                //     'defaultValue': ''
                // }
                
            }
        };
        return properties;
    };

    this.widgetEvents = function () {
        return {
        	'DoubleClicked': {}
        };
    };


    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-piechart2"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span>'+ TW.IDE.I18NController.translate('Pie Chart2') +'</span></td></tr></table></div>';
        return html;
    };

    this.afterSetProperty = function (name, value) {
        if (name === 'Width' || name === 'Height') {
            return true;
        }
    };
    
};