// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

$scope.getProjects = function() {
  $http.get('/ExperienceService/content/projects/', {
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      "Accept": "application/json",
      "Content-Type": "application/json"
    }
  }).then(function(resp){
    _.set($scope.app, 'app.mdl.experienceService.svc.getProjects.data', {rows: resp.data});
    $scope.setWidgetProp('dataGrid-1', 'data', resp.data);
    $scope.$applyAsync();
    console.log("done getting projects", resp);
  }, function(err) {
    console.log('error getting projects', err);
  });
};

$scope.getProjects();

$scope.unpublish = function (item, el) {
  var widgetId = this.widgetId;
  console.log(item, widgetId);
  let url = '/ExperienceService/content/projects/' + encodeURIComponent(item.name);
  $http({
    method: 'DELETE',
    url: url,
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      "Accept": "application/json",
      "Content-Type": "application/json"
    },
    data: ''
  }).then(function (res) {
    var a = $scope.app.app.mdl.experienceService.svc.getProjects.data.rows;
    a.splice(a.indexOf(item), 1);    
    
    console.log("done unpublish", res);
  }, function (err) {
    console.log('error unpublishing', err);
  });
};